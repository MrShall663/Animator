package fileparsing;

import static org.junit.Assert.assertEquals;

import static org.junit.Assert.assertNotNull;


import java.util.HashMap;

import java.util.Map;
import main.ExcellenceMain;

import model.CanvasModel;
import model.EllipseModel;
import model.RectangleModel;

import org.junit.Test;

/**
 * Tests for AnimationModelImpl.
 */
public class FileParsingTest {


  private static String inputFile = null;
  private static String viewMode = null;
  private static Map<String, String> commandLineArgs = new HashMap<>();
  private static final String FILE_NAME = "testdummy.txt";
  private static CanvasModel canvasModel = null;

  static {
    commandLineArgs.put("-view", "text"); // svg text visual (java swing)
    commandLineArgs.put("-speed", "1"); // tempo speed
    commandLineArgs.put("-in", "smalldemo.txt"); // reading file of input of animations.
    commandLineArgs.put("-out", FILE_NAME); // textfile.txt or "" (print to console)
    canvasModel = ExcellenceMain.readFileToModel(commandLineArgs);
  }

  @Test
  public void createCanvasModelFromFile() {
    assertNotNull(canvasModel);
  }

  @Test
  public void correctNumberOfShapes() {
    assertEquals(2, canvasModel.getShapeModel().size());
  }

  @Test
  public void correctNumberOfMotionsForRect() {
    RectangleModel rectangleModel = (RectangleModel) canvasModel.getShapeModel()
        .get(0); // index 0 first shape is a rect in the file...
    assertEquals(10, rectangleModel.getMotions().size() * 2);
  }

  @Test
  public void correctNumberOfMotionsForEllipse() {
    EllipseModel ellipseModel = (EllipseModel) canvasModel.getShapeModel()
        .get(1);  // second shape is an ellipse in the file..
    assertEquals(10, ellipseModel.getMotions().size() * 2);
  }

  @Test
  public void testCanvasWidthAndHeight() {
    assertEquals(360, canvasModel.getWidth());
    assertEquals(360, canvasModel.getHeight());
  }


  @Test
  public void testViewBoxStartXandY() {
    assertEquals(200, canvasModel.getX());
    assertEquals(70, canvasModel.getY());
  }

}