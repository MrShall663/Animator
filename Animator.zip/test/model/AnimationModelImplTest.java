package model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import org.junit.Test;

/**
 * Tests for AnimationModelImpl.
 */
public class AnimationModelImplTest {

  AnimationModel model1 = new AnimationModelImpl();
  ShapeModel shape1 = new ShapeModelImpl(ShapeEnum.ELLIPSE, "Test1", "circle",
      1, 1, 1, 1, 100, 100, 100);
  ShapeModel shape2 = new ShapeModelImpl(ShapeEnum.RECTANGLE, "Test2", "square",
      2, 2, 2, 2, 5, 6, 7);
  ShapeModel shape3 = new ShapeModelImpl(ShapeEnum.RECTANGLE, "Test3", "rectangle",
      4, 4, 4, 4, 11, 12, 13);
  List<TickModel> tickModelList = new ArrayList<>();
  ArrayList<String> stringList = new ArrayList<>();
  TickModel tickModel1 = new TickModelImpl(0, shape1);
  TickModel tickModel2 = new TickModelImpl(1, shape2);
  TickModel tickModel3 = new TickModelImpl(2, shape3);

  @Test
  public void testGetTypeOfShape() {
    model1.addShape("Test1", shape1, 0);
    model1.addShape("Test2", shape2, 1);
    assertEquals("circle", model1.getTypeOfShape("Test1"));
    assertEquals("square", model1.getTypeOfShape("Test2"));
  }

  @Test
  public void testGetCurrentTick() {
    model1.addShape("Test1", shape1, 0);
    model1.addShape("Test2", shape2, 1);
    assertEquals(0, model1.getCurrentTick());
  }

  @Test
  public void testGetLastTick() {
    model1.addShape("Test1", shape1, 0);
    model1.addShape("Test2", shape2, 1);
    assertEquals(1, model1.getLastTick());
    model1.addShape("Test3", shape3, 3);
    assertEquals(3, model1.getLastTick());
  }

  @Test
  public void testTick() {
    model1.tick(1);
    assertEquals(1, model1.getCurrentTick());
    model1.tick(1);
    assertEquals(2, model1.getCurrentTick());
  }

  @Test
  public void testGetShapeNames() {
    model1.addShape("Test1", shape1, 0);
    model1.addShape("Test2", shape2, 1);
    stringList.add("Test1");
    stringList.add("Test2");
    assertTrue(stringList.equals(model1.getShapeNames()));
  }

  @Test
  public void testFails() {
    model1.addShape("Test1", shape1, 0);
    model1.addShape("Test2", shape2, 1);
    tickModelList.add(tickModel1);
    tickModelList.add(tickModel2);
    assertFalse(tickModelList.equals(model1.getAnimation("Test2")));
  }
}