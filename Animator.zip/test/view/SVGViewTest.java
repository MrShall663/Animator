package view;

import java.awt.Color;
import java.awt.Rectangle;
import java.awt.Shape;
import model.AnimationModel;
import model.AnimationModelImpl;
import model.ShapeModel;
import org.junit.Test;


import java.awt.geom.Ellipse2D;

import static org.junit.Assert.assertEquals;

/**
 * Tests the SVG View. Getting an error "model.AnimationModel is abstract; cannot be instantiated".
 * Looking for solution.
 */
public class SVGViewTest {

  @Test
  public void animatorSVGTest1() {
    AnimationModel model = new AnimationModelImpl();
    Appendable outt = new StringBuilder();
    View svg = new SVGView(new AnimationModel(model), outt);
    svg.render(1);
    assertEquals("<svg width=\"1000\" height=\"1000\" version=\"1.1\"\n"
        + "     xmlns=\"http://www.w3.org/2000/svg\">\n"
        + "\n"
        + "</svg>", outt.toString());
  }


  @Test
  public void animatorSVGTest2() {
    AnimationModel model = new AnimationModelImpl();
    ShapeModel rect = new Rectangle("R", 1, 100, new Color(1, 0, 0),
        200.0, 200.0, 200.0, 200.0);
    Shape oval = new Ellipse2D("C", 6, 100, new Color(0, 0, 1),
        500.0, 100.0, 200.0, 200.0);
    model.addShape(rect);
    model.addShape(oval);
    Appendable outt = new StringBuilder();
    View svg = new SVGView(new AnimationModel(model), outt);
    svg.render(100);
    assertEquals("<svg width=\"1000\" height=\"1000\" version=\"1.1\"\n"
        + "     xmlns=\"http://www.w3.org/2000/svg\">\n"
        + "\n"
        + "<rect id=\"R\" x=\"200.0\" y=\"200.0\" width=\"200.0\" height=\"200.0\" "
        + "fill=\"rgb(1,0,0)\" visibility=\"hidden\" >\n"
        + "    <animate attributeType=\"xml\" begin=\"10.0ms\" dur=\"1ms\" "
        + "attributeName=\"visibility\" from=\"hidden\" to=\"visible\" fill=\"freeze\" />\n"
        + "    <animate attributeType=\"xml\" begin=\"1000.0ms\" dur=\"1ms\" "
        + "attributeName=\"visibility\" from=\"visible\" to=\"hidden\" fill=\"freeze\" />\n"
        + "</rect>\n"
        + "\n"
        + "<ellipse id=\"C\" cx=\"500.0\" cy=\"100.0\" rx=\"200.0\" ry=\"200.0\" "
        + "fill=\"rgb(0,0,1)\" visibility=\"hidden\" >\n"
        + "    <animate attributeType=\"xml\" begin=\"60.0ms\" dur=\"1ms\" "
        + "attributeName=\"visibility\" from=\"hidden\" to=\"visible\" fill=\"freeze\" />\n"
        + "    <animate attributeType=\"xml\" begin=\"1000.0ms\" dur=\"1ms\" "
        + "attributeName=\"visibility\" from=\"visible\" to=\"hidden\" fill=\"freeze\" />\n"
        + "</ellipse>\n"
        + "\n"
        + "</svg>", outt.toString());
  }
}

