package view;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.StringReader;
import model.AnimationModel;
import model.AnimationModelImpl;
import org.junit.Test;

/**
 * Tests the Text view.
 */
public class TextViewTest {

  StringReader reader = new StringReader(
      "canvas 100 90 480 480\n"
          + "shape R Circle\n"
          + "motion R 1  150 150 50 100 255 0  0    10  150 150 50 100 255 0  0\n"
          + "motion R 10 300 200 50 100 205 0  0    20  300 300 50 100 255 88  0\n"
          + "motion R 20 300 205 50 100 205 0  88    30  205 300 25 205 0 205  0\n"
          + "motion R 30 205 300 25 100 0 255  0    50  205 205 25 50 0 255  0\n"
          + "shape C ellipse\n"
          + "motion C 5  50 70 120 60 0 0 255      10 440 70 120 60 0 0 255\n"
          + "motion C 10 50 70 120 60 0 0 255      30 50 250 50 60 0 0 255\n"
          + "motion C 30 440 50 120 60 0 0 255     120 20 90 80 120 0 170 85\n"
          + "motion C 130 50 370 240 120 0 170 85    150 220 90 240 60 0 255 0\n");

  @Test
  public void testRender1() throws IOException {
    AnimationModel model = new AnimationModelImpl();
    StringBuilder testModelOutput = new StringBuilder();
    View textView = new TextView();
    textView.setTicks(5);
    textView.setOutput(testModelOutput);
    textView.render(testModelOutput);
    assertEquals("canvas 200 70 360 360\n"
            + "shape R rectangle\n"
            + "motion R 1  80 150 50 100 255 0  0    10  150 150 50 100 255 0  0\n"
            + "motion R 10 80 200 50 80 205 0  0    20  300 300 80 100 255 88  0\n"
            + "motion R 20 80 205 50 80 205 0  88    30  205 300 25 205 0 205  0\n"
            + "motion R 30 80 300 25 100 0 255  0    50  205 205 25 50 0 255  0\n"
            + "shape C ellipse\n"
            + "motion C 5  80 70 120 60 0 0 255      10 440 70 120 60 0 0 255\n"
            + "motion C 10 80 70 120 60 0 0 255      30 80 250 50 60 0 0 255\n"
            + "motion C 30 440 50 120 80 0 0 255     120 20 80 80 120 0 170 85\n"
            + "motion C 80 50 370 240 120 0 170 85    150 220 90 240 60 0 255 0\n",
        testModelOutput.toString());
  }

  @Test
  public void testRender2() throws IOException {
    AnimationModel model = AnimationModelImpl();
    StringBuilder testModelOutput = new StringBuilder();
    View textView = new TextView();
    textView.setTicks(10);
    textView.setOutput(testModelOutput);
    textView.render(model);
    assertEquals("canvas 200 70 360 360\n"
            + "shape R rectangle\n"
            + "motion C 5  80 70 120 60 0 0 255      10 440 70 120 60 0 0 255\n"
            + "motion C 10 84 70 120 60 0 0 255      30 80 84 50 84 0 0 255\n"
            + "motion C 30 440 50 120 80 84 0 255     120 20 80 80 120 0 170 85\n"
            + "motion C 80 50 370 240 120 84 170 85    150 220 84 240 60 84 255 0\n",
        "shape C ellipse\n"
            + "motion R 1  80 150 84 100 255 0  0    10  150 150 50 84 255 0  0\n"
            + "motion R 84 80 200 50 80 205 0  0    20  300 84 80 100 255 88  0\n"
            + "motion R 20 80 84 50 80 205 0  88    30  205 300 25 205 84 205  0\n"
            + "motion R 84 80 300 25 100 0 255  0    50  84 205 25 50 0 255  0\n",
        testModelOutput.toString());
  }
}
