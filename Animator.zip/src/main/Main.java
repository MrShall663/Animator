package main;

import java.io.File;
import java.io.FileWriter;

/**
 * This generates an SVG animation file. The animation is a magnet that bounces off the same
 * polarity magnet balls/bars.
 */

public class Main {

  public static void main(String[] args) {
    writeToFile(makeSVG(), "dynamic.svg");
  }

  /**
   * make the svg view.
   *
   * @return String the tag
   */
  private static String makeSVG() {
    return String.format("<svg viewBox=\"0 0 50 50\" xmlns=\"http://www.w3.org/2000/svg\">\n" +
        "\n"
        +
        "<path id=\"lineAB\" d=\"M 20 0 20 5\" stroke=\"grey\"\n" +
        "  stroke-width=\"1\" fill=\"none\" />\n" +
        "  <rect width=\"5\" height=\"20\" x=\"35%%\" y = \"10%%\" "
        + "stroke=\"black\" stroke-width=\".5\" fill=\"%s\">\n"
        +
        "\t <animate attributeName=\"y\" id=\"rectout\" values=\"18%%;31%%;18%%\" begin=\"0s\" "
        + "dur=\"3s\" repeatCount=\"indefinite\" />\n"
        +
        "  </rect> \n" +
        "  \n" +
        "  <circle r=\"2\" cx=\"40%%\" cy = \"14%%\" fill=\"none\" >\n" +
        "    <animate attributeName=\"fill\" id=\"yellowlight\" values=\"%s;transparent\" "
        + "begin=\"0s;bluelight.end\" dur=\"1s\" repeatCount=\"once\" />\n"
        +
        "  </circle>\n" +
        "\n" +
        "  \n" +
        "  \n" +
        "  <circle r=\"2\" cx=\"40%%\" cy = \"76%%\" fill=\"none\" >\n" +
        "    <animate attributeName=\"fill\" id=\"bluelight\" values=\"%s;transparent\" "
        + "begin=\"yellowlight.end\" dur=\"2s\" repeatCount=\"once\" />\n"
        +
        "  </circle>\n" +
        "  <path id=\"lineAB\" d=\"M 20 40 20 45\" stroke=\"grey\"\n" +
        "  stroke-width=\"1\" fill=\"none\" />\n" +
        "  \n" +
        "\n" +
        "</svg>", "black", "green", "yellow");


  }

  /**
   * writeToFile.
   */
  private static void writeToFile(String textToWrite, String fileName) {

    FileWriter fw = null;

    try {
      fw = new FileWriter(new File(fileName));
      fw.write(textToWrite);
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      try {
        fw.close();
      } catch (Exception e) {
        e.printStackTrace();
      }

    }

  }
}
