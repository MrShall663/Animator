import view.SVGView;
import view.TextView;
import view.View;

/**
 * The class if the factory for the view, and generates views.
 */
public final class ViewFactory {

  /**
   * Factory for view.
   *
   * @param name is the name of the view.
   * @return a new View depending on name.
   * @throws IllegalArgumentException if the view does not exist.
   */
  public static View getView(String name) throws IllegalArgumentException {
    switch (name.toLowerCase()) {
      case "text":
        return new TextView();
      case "svg":
        return new SVGView();
      default:
        throw new IllegalArgumentException("View type must be text, visual, or svg.");
    }
  }

}