
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import model.CanvasModel;
import model.CircleModel;
import model.EllipseModel;
import model.MotionModel;
import model.RectangleModel;
import model.ShapeEnum;
import model.ShapeModelImpl;
import util.AnimationReader;
import view.VisualView;


/**
 * Represents the main method of the animation, and is used to start it with specific commands.
 */
public class ExCELlenceMain {

  private static String inputFile = null;
  private static String viewMode = null;
  private static String outputFile = null;
  private static int ticksPerSecond = 1;

  private static Map<String, String> commandLineArgs = new HashMap<>();

  /**
   * Main method to start the animation.
   *
   * @param args is the console line arguments.
   */
  public static void main(String[] args) {

    try {

      commandLineArgs.put("-view", ""); // svg text visual (java swing)
      commandLineArgs.put("-speed", "1"); // tempo speed
      commandLineArgs.put("-in", ""); // reading file of input of animations.
      commandLineArgs.put("-out", ""); // textfile.txt or "" (print to console)
      for (int i = 0; i < args.length; i = i + 2) {
        commandLineArgs.put(args[i], args[i + 1]);
      }

      readViewMode(args);
      readInputFile(args);
      readOutputFile(args);
      readSpeed(args);
      start();
    } catch (IllegalArgumentException | FileNotFoundException e) {
      System.out.println(e.getMessage());
    }
  }

  /**
   * Starts animation. INCOMPLETE.
   */
  private static void start() throws FileNotFoundException {
    CanvasModel canvasModel = readFileToModel(commandLineArgs);

    switch (commandLineArgs.get("-view")) {
      case "svg":
        String svgOutput = AnimationReader.makeSVGText(canvasModel);
        if (commandLineArgs.get("-out").trim().isEmpty()) {
          // print to console
          System.out.println(svgOutput);
        } else {
          writeToFile(svgOutput, commandLineArgs.get("-out").trim());
        }
        break;
      case "text":
        if (commandLineArgs.get("-out").trim().isEmpty()) {
          // print to console..
          printToConsole(canvasModel);
        } else {
          writeToFile(canvasModel, commandLineArgs.get("-out").trim());
        }
        break;
      case "visual":
        VisualView visualView = new VisualView(canvasModel);
        visualView.render();
        break;
      default:
        break;
    }
  }


  private static void writeToFile(String textToWrite, String fileName) {

    FileWriter fw = null;

    try {
      fw = new FileWriter(new File(fileName));
      fw.write(textToWrite);
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      try {
        fw.close();
      } catch (Exception e) {
        e.printStackTrace();
      }

    }

  }

  private static void writeToFile(CanvasModel canvasModel, String fileName) {

    FileWriter fw = null;

    try {
      fw = new FileWriter(new File(fileName));
      fw.write(canvasModel.toString());
      for (ShapeModelImpl shapeModel : canvasModel.getShapeModel()) {
        fw.write(shapeModel.toString());
        for (MotionModel[] motions : shapeModel.getMotions()) {
          int i = 0;
          for (MotionModel motionModel : motions) {
            String motionStr = motionModel.toString();
            if (i == 1) {
              motionStr = motionStr.replace("motion", "");
              motionStr = motionStr.replace(motionModel.getShapeName(), "");
            }
            fw.write(motionStr);
            i++;
          }
          i = 0;
          fw.write("\n");
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      try {
        fw.close();
      } catch (Exception e) {
        e.printStackTrace();
      }

    }

  }

  private static void printToConsole(CanvasModel canvasModel) {

    System.out.print(canvasModel.toString());
    for (ShapeModelImpl shapeModel : canvasModel.getShapeModel()) {
      System.out.print(shapeModel.toString());
      for (MotionModel[] motions : shapeModel.getMotions()) {
        for (MotionModel motionModel : motions) {
          System.out.print(motionModel.toString());
          System.out.print(" ");
        }
        System.out.println("");
      }
      System.out.println("");
    }
  }

  /**
   * Finds the view mode.
   *
   * @param args is the console line arguments.
   * @throws IllegalArgumentException if there is no console line argument with -view.
   */
  private static void readViewMode(String[] args) throws IllegalArgumentException {
    viewMode = getArg(args, "-view");
    if (viewMode == null) {
      throw new IllegalArgumentException("There must be a -view command.");
    }
  }

  /**
   * Saves argument to input file.
   *
   * @param args is the console line arguments.
   * @throws IllegalArgumentException if there is no console line argument with -in.
   */
  private static void readInputFile(String[] args) throws IllegalArgumentException {
    inputFile = getArg(args, "-in");
    if (inputFile == null) {
      throw new IllegalArgumentException("The -in argument must be provided.");
    }
  }

  /**
   * Saves argument to output file.
   *
   * @param args is the console line arguments.
   */
  private static void readOutputFile(String[] args) {
    outputFile = getArg(args, "-out");
  }

  /**
   * Reads the speed argument.
   *
   * @param args the console line arguments.
   */
  private static void readSpeed(String[] args) {
    String speed = getArg(args, "-speed");
    try {
      ticksPerSecond = Integer.valueOf(speed);
    } catch (NullPointerException | IllegalArgumentException e) {
      ticksPerSecond = 1; // default;
    }
  }

  /**
   * Finds the specifier necessary.
   *
   * @param args      is the console line arguments.
   * @param specifier the argument to search for.
   * @return the specific argument or null if there is none.
   */
  private static String getArg(String[] args, String specifier) {
    for (int i = 0; i < args.length; i++) {
      if (args[i].equals(specifier) && i + 1 < args.length) {
        return args[i + 1];
      }
    }
    return null;
  }

  private static void addShapeFromLine(String line, List<ShapeModelImpl> shapes) {
    Scanner lineScanner = new Scanner(line);
    lineScanner.next(); // skip past the word shape
    String shapeName = lineScanner.next(); // 1 letter character... like R, or C
    String shapeStr = lineScanner.next();
    // TODO FIND OUT THE SIZE OF THE SHAPE.. E.G. the width and height of a rectangle...

    ShapeModelImpl newShape = null;
    ShapeEnum shapeEnum = null;
    switch (shapeStr.toUpperCase()) {
      case "CIRCLE":
        shapeEnum = ShapeEnum.CIRCLE;
        newShape = new CircleModel(shapeEnum, shapeName, shapeStr, 200, 70, 50, 150, 100, 50, 50);
        break;
      case "RECTANGLE":
        shapeEnum = ShapeEnum.RECTANGLE;
        newShape = new RectangleModel(shapeEnum, shapeName, shapeStr, 200, 70, 50, 150, 100, 50,
            50);
        break;
      case "ELLIPSE":
        shapeEnum = ShapeEnum.ELLIPSE;
        newShape = new EllipseModel(shapeEnum, shapeName, shapeStr, 200, 70, 50, 150, 100, 50, 50);
        break;
      default:
        break;
    }

    // BEFORE FAKE VALUES.... all were 0 0 0 0 0 0 0

    shapes.add(newShape);
  }

  private static void addMotionToShape(String line, List<ShapeModelImpl> shapes) {

    MotionModel[] arrayMotions = new MotionModel[2];
    Scanner lineScanner = new Scanner(line);
    // skip motion
    lineScanner.next();
    final String shapeNameT = lineScanner.next();
    int i = 0;
    // set of 2 motions must be added to the previous shape
    ShapeModelImpl shapeByName = shapes.stream().filter(x -> x.getName().equals(shapeNameT))
        .findFirst().get();
    MotionModel motionModel = null;
    while (i < 2) {
      // first start motion
      motionModel = new MotionModel(shapeByName.getShapeType(), shapeNameT, i,
          lineScanner.nextInt(), lineScanner.nextInt(),
          lineScanner.nextInt(), lineScanner.nextInt(), lineScanner.nextInt(),
          lineScanner.nextInt(), lineScanner.nextInt(), lineScanner.nextInt());
      String speedArg = commandLineArgs.get("-speed");
      motionModel.setSpeed(speedArg.isEmpty() ? 1 : Integer.parseInt(speedArg));
      List<MotionModel[]> motions = shapeByName.getMotions();
      if (motions == null) {
        motions = new ArrayList<>();
      }
      arrayMotions[i] = motionModel;

      // second end motion
      i++;
      motionModel = new MotionModel(shapeByName.getShapeType(), shapeNameT, i,
          lineScanner.nextInt(), lineScanner.nextInt(),
          lineScanner.nextInt(), lineScanner.nextInt(), lineScanner.nextInt(),
          lineScanner.nextInt(), lineScanner.nextInt(), lineScanner.nextInt());
      motionModel.setSpeed(speedArg.isEmpty() ? 1 : Integer.parseInt(speedArg));
      arrayMotions[i] = motionModel;

      motions.add(arrayMotions);
      shapeByName.setMotions(motions);
      i++;
    }
  }

  private static CanvasModel addCanvasFromLine(String line) {
    Scanner lineScanner = new Scanner(line);
    CanvasModel canvasModel = new CanvasModel();
    canvasModel.setName(lineScanner.next());
    canvasModel.setShapeType(ShapeEnum.CANVAS);
    canvasModel.setX(lineScanner.nextInt());
    canvasModel.setY(lineScanner.nextInt());
    canvasModel.setWidth(lineScanner.nextInt());
    canvasModel.setHeight(lineScanner.nextInt());
    return canvasModel;
  }


  /**
   * Reads a file to the model.
   *
   * @param commArgs is Hash Map
   * @return the model.
   * @throws IllegalArgumentException if the file is not found or contains errors.
   */
  private static CanvasModel readFileToModel(Map<String, String> commArgs)
      throws IllegalArgumentException {

    List<ShapeModelImpl> shapes = new ArrayList<>();
    int index = -1;
    CanvasModel canvasModel = null;
    try {

      if (!commArgs.containsKey("-in") || !commArgs.containsKey("-view")) {
        throw new IllegalArgumentException();
      }

      BufferedReader bufferedReader = new BufferedReader(
          new InputStreamReader(new FileInputStream(commArgs.get("-in"))));
      int i = 0;
      MotionModel[] arrayMotions;

      String line = null;

      // reading line by line util of file.
      while ((line = bufferedReader.readLine()) != null) {

        if (line.trim().isEmpty()) {
          continue;
        }
        if (line.charAt(0) == '#') {
          continue;
        }

        if (line.contains("canvas")) {
          canvasModel = addCanvasFromLine(line);
          canvasModel.setShapeModel(shapes);
        }
        if (line.contains("shape")) {
          addShapeFromLine(line, shapes);
        }
        if (line.charAt(0) != '#' && line.contains("motion")) {
          if (line.lastIndexOf("#") != -1) { // found a # and it is a comment.
            line = line.substring(0, line.lastIndexOf("#")).trim();
            String nextLine = bufferedReader.readLine();
            nextLine = nextLine.substring(0, nextLine.lastIndexOf("#"));
            line = line.concat(nextLine);
          }

          addMotionToShape(line, shapes);

        }

      }

      return canvasModel;
      // ShapeModelImpl shapeModel = new ShapeModelImpl();

    } catch (FileNotFoundException e) {
      throw new IllegalArgumentException("Error. File not found: " + e.getMessage());
    } catch (IllegalArgumentException e) {
      throw new IllegalArgumentException("Error. Problem loading file as animation: "
          + e.getMessage());
    } catch (IOException e) {
      e.printStackTrace();
    }

    return null;
  }

}