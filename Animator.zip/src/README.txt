MODEL:

AnimationModel(Interface)
This interface defines all the commands that a model for EasyAnimator should have.

AnimationModelImpl(Class) implements AnimatorModel
This class is the model for a basic version of the animator model.

ShapeModel(Interface)
This interface has many methods that we can use for shapes.

ShapeModelImpl(Class) implements ShapeModel
This class is the representation of shapes that have name, type, position, size, and color.

TickModel(Interface)
This interface defines time when we running animations. 

TickModelImpl(Class)
This class is the representation of time in an animation.

MotionModel(Class)
Motions are commands like changing positions, colors, and size of an animation.

CanvasModel(Class)
To store the dimension given in txt file.

VIEW:

AnimatorView(Interface)
This interface is used to define all the methods that an AnimatorView should have.

AnimatorView(Class)
This class is used to show a textual representation of the model. It shows the current shapes
and also the motions/commands they perform.

SVGView (Class)
This class represents the SVG view of the animation.

Util: 
AnimationBuilder(Interface)
This interface is used to build animations. 

AnimationReader(Class)
A helper to read animation data and construct an animation from it.

