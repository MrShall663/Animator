package view;

import java.awt.Graphics;
import java.awt.Graphics2D;
import model.EllipseModel;
import model.ShapeEnum;

import java.awt.geom.Ellipse2D;

/**
 * Represents the EllipseVisualView of the animation.
 */
public class EllipseVisualView extends EllipseModel implements SwiingGraphicsInterface {


  public EllipseVisualView(ShapeEnum shapeType, String name, String shape, int x, int y, int width,
      int height, int r, int g, int b) {
    super(shapeType, name, shape, x, y, width, height, r, g, b);
  }

  @Override
  public void draw(Graphics g) {
    Graphics2D g2d = (Graphics2D) g;
    Ellipse2D.Double circle = new Ellipse2D.Double(this.getX(), this.getY(), this.getWidth(),
        this.getHeight());
    g2d.setColor(this.getSwingColor());
    g2d.fill(circle);
  }

}