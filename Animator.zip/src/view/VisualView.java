package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import model.CanvasModel;
import model.EllipseModel;
import model.RectangleModel;
import model.ShapeModelImpl;

/**
 * Represents the visual view of the animation.
 */
public class VisualView extends JPanel {

  private CanvasModel canvasModel = null;

  /**
   * Constructs a visual view.
   */
  public VisualView(CanvasModel canvasModel) {

    this.canvasModel = canvasModel;
    JScrollPane scrollPane = new JScrollPane(this);
    setBackground(Color.WHITE);
    //setBounds(100, 50, canvasModel.getWidth(), canvasModel.getHeight());
    // setLayout(null)
    setPreferredSize(new Dimension(canvasModel.getWidth(), canvasModel.getHeight()));


  }

  /**
   * render the visual view.
   */
  public void render() {

    JFrame frame = new JFrame();
    frame.add(this);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.pack();
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);

  }


  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g);

    for (ShapeModelImpl shapeModel : this.canvasModel.getShapeModel()) {

      if (shapeModel instanceof EllipseModel) {

        EllipseModel ellipseModel = (EllipseModel) shapeModel;
        EllipseVisualView ellipseVisualView = ellipseModel.toVisualView();
        // NOTE. have to set the x and y position from the motion
        // because no initial values are given...
        ellipseVisualView.setMotionValuesForPositionAndDimesions(ellipseModel.getMotions());
        repaint();
        ellipseVisualView.draw(g);

      } else if (shapeModel instanceof RectangleModel) {

        RectangleModel rectangleModel = (RectangleModel) shapeModel;
        RectangleVisualView rectangleVisualView = rectangleModel.toVisualView();
        rectangleVisualView.setMotionValuesForPositionAndDimesions(rectangleModel.getMotions());
        repaint();
        rectangleVisualView.draw(g);
      }


    }


    /*
    for (Object s : this.canvasModel.ge) {
      if (s instanceof Circle) {
        ((Circle) s).draw(g);
      } else if (s instanceof Star) {
        ((Star) s).draw(g);
      }
    }*/
  }

}
