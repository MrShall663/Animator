package view;

import java.util.List;
import model.ShapeModel;

/**
 * Represents the interface for an animation.
 */
public interface Animation {

  /**
   * Draws a shape.
   *
   * @param shapes is the list of shapes to draw.
   * @throws NullPointerException if the list of shapes is empty.
   */
  void draw(List<ShapeModel> shapes) throws NullPointerException;

}
