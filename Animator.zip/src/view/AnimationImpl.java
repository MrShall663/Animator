package view;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.swing.JPanel;
import model.ShapeModel;

/**
 * Implementation for an animation, that draws a shape.
 */
public class AnimationImpl extends JPanel implements Animation {

  private List<ShapeModel> shapes;

  public AnimationImpl() {
    super();
    this.shapes = new ArrayList<>();
  }

  @Override
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2d = (Graphics2D) g;

    if (shapes != null) {
      for (ShapeModel shape : shapes) {
        g2d.setColor(shape.getColor().getAWTColor());
        int x = shape.getX();
        int y = shape.getY();
        int width = shape.getWidth();
        int height = shape.getHeight();
        switch (shape.getShape().toLowerCase()) {
          case "rectangle":
            g2d.fillRect(x, y, width, height);
            break;
          case "ellipse":
            g2d.fillOval(x, y, width, height);
            break;
          default:
            throw new IllegalArgumentException("Unsupported shape type.");
        }
      }
    }
  }

  @Override
  public void draw(List<ShapeModel> shapes) throws NullPointerException {
    Objects.requireNonNull(shapes);
    this.shapes = shapes;
    this.repaint();
  }
}