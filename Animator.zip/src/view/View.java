package view;

/**
 * Represents the interface for a view.
 */
public interface View {

  /**
   * Renders the view and adds it to appendable.
   *
   * @param out is the appendable.
   * @throws NullPointerException if appendable is empty.
   */
  void render(Appendable out) throws NullPointerException;
}
