package view;

/**
 * This Playback controls add new features to our animation model so that we can pause, restart, and
 * so on in our animator. Start, pause, resume, and restart (i.e. rewind to beginning and start the
 * animation again) the animation with explicit user input (e.g. key press, button click, etc).
 * Enable/disable looping: enabling looping should cause the animation to automatically restart once
 * it reaches the end. Increase or decrease the speed of the animation, as it is being played, and
 * immediately see the results.
 */
public interface PlaybackControl {

  /**
   * Pause the animation.
   */
  void pause();

  /**
   * Restart the animation.
   */
  void restart();

  /**
   * Play the animation.
   */
  void play();

  /**
   * check if the the animation is looped.
   */
  boolean isLoop();

  /**
   * increase the speed of the animation.
   */
  int increaseSpeed();

  /**
   * decrease the speed of the animation.
   */
  int decreaseSpeed();
}
