package view;


import model.CanvasModel;
import util.AnimationReader;

import java.io.File;
import java.io.FileWriter;


/**
 * Represents the SVG view of the animation.
 */
public class SVGView implements View {

  /**
   * Constructs an SVGView for the selected model.
   *
   * @param model the model to be associated with this view
   * @param out the appendable associated with this view
   */
  private CanvasModel canvasModel;

  public SVGView(CanvasModel canvasModel) {
    this.canvasModel = canvasModel;
  }

  /**
   * Converts the string to SVG format.
   *
   * @param out is the appendable.
   */
  public void render(Appendable out) {
    String svgOutput = AnimationReader.makeSVGText(canvasModel);
    System.out.println(svgOutput);
  }

  /**
   * writeToFile.
   */
  public void writeToFile(String fileName) {
    String textToWrite = AnimationReader.makeSVGText(canvasModel);
    FileWriter fw = null;

    try {
      fw = new FileWriter(new File(fileName));
      fw.write(textToWrite);
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      try {
        fw.close();
      } catch (Exception e) {
        e.printStackTrace();
      }

    }

  }


}


