package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 * This Playback controls add new features to our animation model so that we can pause, restart, and
 * so on in our animator. Start, pause, resume, and restart (i.e. rewind to beginning and start the
 * animation again) the animation with explicit user input (e.g. key press, button click, etc).
 * Enable/disable looping: enabling looping should cause the animation to automatically restart once
 * it reaches the end. Increase or decrease the speed of the animation, as it is being played, and
 * immediately see the results.
 */
public class PlaybackControls implements View {

  private final VisualView delegate;
  private PlaybackControl features;

  public PlaybackAnimatorView() {
    this.delegate = new View();
  }

  @Override
  public void render(Animation model) throws IllegalArgumentException, IOException {
    this.delegate.render();
    this.delegate.addKeyListener(new PlaybackKeyListener());
    this.delegate.add(new ButtonPanel(), BorderLayout.EAST);
  }

  private class ButtonPanel extends JPanel {

    private ButtonPanel() {
      this.setLayout(new FlowLayout());
      JButton pause = new JButton("pause (' ')");
      pause.addActionListener(e -> {
        features.pause();
        delegate.requestFocus();
      });
      this.add(pause);
      JButton play = new JButton("play ('p')");
      play.addActionListener(e -> {
        features.play();
        delegate.requestFocus();
      });
      this.add(play);
      JButton restart = new JButton("restart ('r')");
      restart.addActionListener(e -> {
        features.restart();
        delegate.requestFocus();
      });
      this.add(restart);
      JButton loop = new JButton("loop ('l')");
      loop.addActionListener(e -> {
        features.isLoop();
        delegate.requestFocus();
      });
      this.add(loop);
      JButton faster = new JButton("faster ('+')");
      faster.addActionListener(e -> {
        features.increaseSpeed();
        delegate.requestFocus();
      });
      this.add(faster);
      JButton slower = new JButton("slower ('-')");
      slower.addActionListener(e -> {
        features.decreaseSpeed();
        delegate.requestFocus();
      });
      this.add(slower);
      this.setPreferredSize(new Dimension(150, delegate.getHeight() / 2));
    }
  }

  private class PlaybackKeyListener implements KeyListener {

    @Override
    public void keyTyped(KeyEvent e) {
      switch (e.getKeyChar()) {
        case ' ':
          features.pause();
          break;
        case 'r':
          features.restart();
          break;
        case 'p':
          features.play();
          break;
        case 'l':
          features.isLoop();
          break;
        case '+':
          features.increaseSpeed();
          break;
        case '-':
          features.decreaseSpeed();
          break;
        default:
          break;
      }
    }

    @Override
    public void keyPressed(KeyEvent e) {
      this.keyReleased(e);
    }

    @Override
    public void keyReleased(KeyEvent e) {
      this.keyPressed(e);
    }
  }
}
