package view;


import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import model.RectangleModel;
import model.ShapeEnum;

/**
 * Represents the RectangleVisualView of the animation.
 */
public class RectangleVisualView extends RectangleModel implements SwiingGraphicsInterface {


  public RectangleVisualView(ShapeEnum shapeType, String name, String shape, int x, int y,
      int width, int height, int r, int g, int b) {
    super(shapeType, name, shape, x, y, width, height, r, g, b);
  }

  @Override
  public void draw(Graphics g) {
    Graphics2D g2d = (Graphics2D) g;
    Rectangle rectangle = new Rectangle(this.getX(), this.getY(), this.getWidth(),
        this.getHeight());
    g2d.setColor(this.getSwingColor());
    g2d.fill(rectangle);
  }

}