package view;


import java.awt.Graphics;
import java.awt.Shape;
import java.io.File;
import java.io.FileWriter;


import javax.swing.text.BadLocationException;
import javax.swing.text.Position;
import javax.swing.text.View;
import model.CanvasModel;
import model.MotionModel;
import model.ShapeModelImpl;

/**
 * Represents the text view of the animation.
 */
public class TextView extends View implements view.View {


  private CanvasModel canvasModel;

  public TextView() {
    super(null);

  }

  public TextView(CanvasModel canvasModel) {
    super(null);
    this.canvasModel = canvasModel;
  }

  /**
   * printToConsole.
   */
  public void printToConsole() {

    System.out.print(canvasModel.toString());
    for (ShapeModelImpl shapeModel : canvasModel.getShapeModel()) {
      System.out.print(shapeModel.toString());
      for (MotionModel[] motions : shapeModel.getMotions()) {
        for (MotionModel motionModel : motions) {
          System.out.print(motionModel.toString());
          System.out.print(" ");
        }
        System.out.println("");
      }
      System.out.println("");
    }
  }

  /**
   * writeToFile.
   */
  public void writeToFile(String fileName) {

    FileWriter fw = null;

    try {
      fw = new FileWriter(new File(fileName));
      fw.write(this.canvasModel.toString());
      for (ShapeModelImpl shapeModel : this.canvasModel.getShapeModel()) {
        fw.write(shapeModel.toString());
        for (MotionModel[] motions : shapeModel.getMotions()) {
          int i = 0;
          for (MotionModel motionModel : motions) {
            String motionStr = motionModel.toString();
            if (i == 1) {
              motionStr = motionStr.replace("motion", "");
              motionStr = motionStr.replace(motionModel.getShapeName(), "");
            }
            fw.write(motionStr);
            i++;
          }
          i = 0;
          fw.write("\n");
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      try {
        fw.close();
      } catch (Exception e) {
        e.printStackTrace();
      }

    }

  }

  @Override
  public float getPreferredSpan(int axis) {
    return 0;
  }

  @Override
  public void paint(Graphics g, Shape allocation) {
    this.canvasModel.getEndTag();
  }


  @Override
  public Shape modelToView(int pos, Shape a, Position.Bias b) throws BadLocationException {
    return null;
  }

  @Override
  public int viewToModel(float x, float y, Shape a, Position.Bias[] biasReturn) {
    return 0;
  }

  @Override
  public void render(Appendable out) throws NullPointerException {
    this.canvasModel.getEndTag();
  }
}
