package view;

import java.awt.Graphics;

/**
 * Represents the SwiingGraphicsInterface of the animation.
 */
public interface SwiingGraphicsInterface {

  public void draw(Graphics g);
}
