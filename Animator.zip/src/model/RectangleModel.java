package model;

import view.RectangleVisualView;

/*

Sample Rectangle SVG that his class will model
https://github.com/cindy1u0/Easy-Animator
  <rect width="300" height="100" />

* */

/**
 * This class is the representation of a rectangle that has shape animations.
 */
public class RectangleModel extends ShapeModelImpl {


  /**
   * Represents the implementation of the methods in the ShapeModel interface.
   *
   * @param shapeType is the type of shape.
   * @param name      is the type of shape.
   * @param shape     is the type of shape.
   * @param x         is the type of shape.
   * @param y         is the type of shape.
   * @param width     is the type of shape.
   * @param height    is the type of shape.
   * @param r         is the type of shape.
   * @param g         is the type of shape.
   * @param b         is the type of shape.
   */
  public RectangleModel(ShapeEnum shapeType, String name, String shape, int x, int y, int width,
      int height, int r, int g, int b) {
    super(shapeType, name, shape, x, y, width, height, r, g, b);
  }

  /**
   * Get the start tag.
   *
   * @return String the tag
   */
  public String getStartTag() {
    StringBuilder sb = new StringBuilder();
    sb.append("<rect ");
    sb.append("width=\"");
    sb.append(getWidth());
    sb.append("\"");
    sb.append(" height=\"");
    sb.append(getHeight());
    sb.append("\"");
    sb.append(">");
    return sb.toString();
  }

  public String getEndTag() {
    return ShapeEnum.RECTANGLE.getEndTag();
  }

  /**
   * Get the visual view for the ellipse.
   *
   * @return EllipseVisualView the view
   */
  public RectangleVisualView toVisualView() {
    RectangleVisualView rectangleVisualView = new RectangleVisualView(this.getShapeType(),
        this.getName(), this.getShape(), this.getX(), this.getY(), this.getWidth(),
        this.getHeight(), this.getColor().r, this.getColor().g, this.getColor().b);
    return rectangleVisualView;

  }

  @Override
  public String toString() {
    return String.format("%s %s %s\n", "shape", getName(), getShape());
  }
}
