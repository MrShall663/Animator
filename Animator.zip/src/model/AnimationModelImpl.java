package model;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.function.ToDoubleFunction;

/**
 * Represents the model for an animation.
 */
public class AnimationModelImpl implements AnimationModel {

  private final HashMap<String, List<TickModel>> animations;
  private final HashMap<String, String> shapes;
  private final List<String> shapeNames;
  private int currentTick;

  /**
   * Constructs an animation model.
   */
  public AnimationModelImpl() {
    this.animations = new HashMap<>();
    this.shapes = new HashMap<>();
    this.shapeNames = new ArrayList<>();
    this.currentTick = 0;
  }

  /**
   * Constructor.
   *
   * @param fileName file name
   * @throws FileNotFoundException throw exception if nothing found.
   */
  public AnimationModelImpl(String fileName) throws FileNotFoundException {
    this.animations = new HashMap<>();
    this.shapes = new HashMap<>();
    this.shapeNames = new ArrayList<>();
    this.currentTick = 0;
    Scanner scanner = new Scanner(new FileReader(fileName));
    while (scanner.hasNextLine()) {
      String nextLine = scanner.nextLine();
      if (!nextLine.trim().isEmpty() && nextLine.charAt(0) == '#') {
        continue;
      }
      System.out.println(nextLine);
    }
  }

  /**
   * Adds a shape and/or its animation to list of animations.
   *
   * @param name  is the name of the shape.
   * @param shape is the type of shape.
   */
  public void addShape(String name, ShapeModel shape) {
    this.addShape(name, shape, 0);
  }

  /**
   * Adds a shape and/or its animation to the list of animations.
   *
   * @param name  is the name of the shape.
   * @param shape is the type of shape.
   * @param tick  is the time when the shape and/pr animation is added.
   */
  public void addShape(String name, ShapeModel shape, int tick) {
    if (name == null || name.trim().isEmpty() || shape == null || tick < 0) {
      throw new IllegalArgumentException("Name must be unique, and must contain characters,"
          + "shape must not be null, and tick must be greater than 0");
    }
    this.addAnimation(name, shape, tick);

  }

  /**
   * Adds an animation to the list of animations.
   *
   * @param name  is the name of the shape.
   * @param shape is the type of shape.
   * @param tick  is the current time of the animation.
   */
  public void addAnimation(String name, ShapeModel shape, int tick) {
    if (hasShape(name)
        && !this.getTypeOfShape(name).equals(shape.getShape())) {
      throw new IllegalArgumentException("This name does not have associated shape.");
    }
    if (!hasShape(name)) {
      this.shapeNames.add(name);
      this.shapes.put(name, shape.getShape());
      this.animations.put(name, new ArrayList<>());
    }

    List<TickModel> shapeAnimations = this.animations.get(name);
    for (TickModel t : shapeAnimations) {
      if (tick == t.getTick()) {
        throw new IllegalArgumentException("There is already a motion happening at that time.");
      }
    }
    shapeAnimations.add(new TickModelImpl(tick, shape));
  }

  /**
   * Gets the type of shape for a certain named shape.
   *
   * @param name is the name of the shape.
   * @return the type of shape for the given name.
   */
  public String getTypeOfShape(String name) {
    if (this.shapes.containsKey(name)) {
      return this.shapes.get(name);
    } else {
      throw new IllegalArgumentException("Shape does not exist.");
    }
  }


  /**
   * Gets the previous tick time for a previous animation.
   */
  public void tick(int times) {
    if (times > 0) {
      this.currentTick += times;
    }
  }

  /**
   * Gets the current tick.
   *
   * @return the current tick.
   */
  public int getCurrentTick() {
    return this.currentTick;
  }

  /**
   * Gets the previous tick time for a previous animation.
   *
   * @return the previous tick time for a previous animation.
   */
  public int getLastTick() {
    int lastTick = 0;
    for (List<TickModel> tickModel : this.animations.values()) {
      for (TickModel tick : tickModel) {
        if (tick.getTick() > lastTick) {
          lastTick = tick.getTick();
        }
      }
    }
    return lastTick;
  }

  /**
   * Gets the names of all shapes in the animations.
   *
   * @return the names of all shapes in the animations.
   */
  public List<String> getShapeNames() {
    return this.shapeNames;
  }

  /**
   * Gets the list of animations for a given name.
   *
   * @param name is the given name of a shape.
   * @return the animations for the given name shape.
   */
  public List<TickModel> getAnimation(String name) {
    if (name == null || !hasShape(name)) {
      throw new IllegalArgumentException("Need a valid name.");
    }

    return this.animations.get(name);

  }

  /**
   * Checks to see whether the named shape has any animations.
   *
   * @param name is the name of the shape.
   * @return whether the shape has an animation.
   */
  public boolean hasShape(String name) {
    return this.animations.containsKey(name);
  }

  /**
   * Returns the in between value of two points.
   *
   * @param currentTime is the current time.
   * @param before      is the lower bound time.
   * @param after       is the upper bound time.
   * @param getter      is used for calculations.
   * @return
   */
  private int tween(double currentTime, TickModel before, TickModel after,
      ToDoubleFunction<ShapeModel> getter) {
    double beforeVal = getter.applyAsDouble(before.getShape());
    double afterVal = getter.applyAsDouble(after.getShape());
    if (beforeVal == afterVal) {
      return (int) Math.round(beforeVal);
    } else {
      double beforeTime = before.getTick();
      double afterTime = after.getTick();
      double value = beforeVal;
      if (beforeTime <= currentTime && currentTime <= afterTime) {
        value = beforeVal * ((afterTime - currentTime) / (afterTime - beforeTime))
            + afterVal * ((currentTime - beforeTime) / (afterTime - beforeTime));
      }
      return (int) Math.round(value);
    }
  }
}
