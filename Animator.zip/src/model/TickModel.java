package model;

/**
 * Represents the model for the time in an animation.
 */
public interface TickModel {

  /**
   * Gets the current tick of the animation.
   *
   * @return the current tick of the animation.
   */
  int getTick();

  /**
   * Gets the current shape in the animation.
   *
   * @return the current shape in the animation.
   */
  ShapeModel getShape();

  /**
   * Puts the animation in string format.
   *
   * @return what happens in the animation in string format.
   */
  String toString();
}
