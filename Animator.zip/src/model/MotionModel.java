package model;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is a representation of a motion, which include changing colors, positions, and size.
 */
public class MotionModel {

  private int t;
  private int x;
  private int y;
  private int w;
  private int h;
  private int r;
  private int g;
  private int b;
  private String shapeName;


  private ShapeEnum shapeType;
  private int index; // index = 0 means start 1 means end..
  private int speed = 1;

  /**
   * Constructor for the motion model.
   *
   * @param shapeType shape type
   * @param shapeName shape name
   * @param index     index
   * @param t         time
   * @param x         x position
   * @param y         y position
   * @param w         width
   * @param h         height
   * @param r         red
   * @param g         green
   * @param b         blue
   */
  public MotionModel(ShapeEnum shapeType, String shapeName, int index, int t, int x, int y, int w,
      int h, int r, int g,
      int b) {
    this.shapeType = shapeType;
    this.t = t;
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.r = r;
    this.g = g;
    this.b = b;
    this.shapeName = shapeName;
    this.index = index;
  }

  /**
   * Constructor for MotionModel.
   *
   * @param shapeType shape type
   * @param shapeName shape name
   * @param index     index
   * @param t         time
   * @param x         x position
   * @param y         y position
   * @param w         width
   * @param h         height
   * @param r         red
   * @param g         green
   * @param b         blue
   */
  public MotionModel(ShapeEnum shapeType, String shapeName, int index, String t, String x, String y,
      String w, String h,
      String r, String g, String b) {
    this.shapeType = shapeType;
    this.t = Integer.parseInt(t);
    this.x = Integer.parseInt(x);
    this.y = Integer.parseInt(y);
    this.w = Integer.parseInt(w);
    this.h = Integer.parseInt(h);
    this.r = Integer.parseInt(r);
    this.g = Integer.parseInt(g);
    this.b = Integer.parseInt(b);

    this.shapeName = shapeName;
    this.index = index;
  }

  public void setSpeed(int speed) {
    this.speed = speed;
  }

  public int getSpeed() {
    return speed;
  }

  public void setT(int t) {
    this.t = t;
  }

  public void setX(int x) {
    this.x = x;
  }

  public void setY(int y) {
    this.y = y;
  }

  public void setW(int w) {
    this.w = w;
  }

  public void setH(int h) {
    this.h = h;
  }

  public void setR(int r) {
    this.r = r;
  }

  public void setG(int g) {
    this.g = g;
  }

  public void setB(int b) {
    this.b = b;
  }

  public void setShapeName(String shapeName) {
    this.shapeName = shapeName;
  }

  public void setIndex(int index) {
    this.index = index;
  }

  // starts off at 1... but that is incorrect.. really starts at 0...
  // duration is therefore added by 1
  // duration is therefore added by 1
  public int getT() {
    return (t - 1) / getSpeed();
  }

  public int getX() {
    return x;
  }

  public int getY() {
    return y;
  }

  public int getWidth() {
    return w;
  }

  public int getHeight() {
    return h;
  }

  public int getR() {
    return r;
  }

  public int getG() {
    return g;
  }

  public int getB() {
    return b;
  }

  public String getShapeName() {
    return shapeName;
  }

  public int getIndex() {
    return index;
  }

  public ShapeEnum getShapeType() {
    return shapeType;
  }

  public void setShapeType(ShapeEnum shapeType) {
    this.shapeType = shapeType;
  }

  @Override
  public String toString() {
    return String.format("%s %s %d %d %d %d %d %d %d %d",
        "motion", shapeName, getT(), x, y, w, h, r, g, b);
  }

  /**
   * getThePositionYAttr.
   *
   * @return String the tag
   */
  public String getThePositionXAttr() {
    switch (shapeType) {

      case ELLIPSE:
      case CIRCLE:
        return "cx";
      case RECTANGLE:
        return "x";
      default:
        throw new RuntimeException("Must specify a shape for the motion!");
    }
  }

  /**
   * getThePositionYAttr.
   *
   * @return String the tag
   */
  public String getThePositionYAttr() {
    switch (shapeType) {

      case ELLIPSE:
      case CIRCLE:
        return "cy";
      case RECTANGLE:
        return "y";
      default:
        throw new RuntimeException("Must specify a shape for the motion!");
    }
  }

  /**
   * getThePositionYAttr.
   *
   * @return String the tag
   */
  public String getWidthPositionAttr() {
    switch (shapeType) {
      case ELLIPSE:
      case CIRCLE:
        return "rx";
      case RECTANGLE:
        return "width";
      default:
        throw new RuntimeException("Must specify a shape for the motion!");
    }
  }

  /**
   * getThePositionYAttr.
   *
   * @return String the tag
   */
  public String getHeightPositionAttr() {
    switch (shapeType) {
      case ELLIPSE:
      case CIRCLE:
        return "ry";
      case RECTANGLE:
        return "height";
      default:
        throw new RuntimeException("Must specify a shape for the motion!");
    }
  }

  /**
   * getStartTag.
   *
   * @return String the tag
   */
  public static String getStartTag(String attributeName, String attributeValue, String duration,
      String begin) {

    StringBuilder sb = new StringBuilder();
    sb.append("<animate ");
    sb.append("attributeType=\"XML\" ");
    sb.append(String.format("attributeName=\"%s\" ", attributeName));
    sb.append(String.format("values=\"%s\" ", attributeValue));
    sb.append(String.format("begin=\"%s\" ", begin));
    sb.append(String.format("dur=\"%s\" ", duration));
    sb.append("repeatCount=\"once\" ");
    return sb.toString();

  }


  public static String getEndTag() {
    return " />";
  }

  /**
   * Get the FullAnimationTag.
   *
   * @return String the tag
   */
  public static String getFullAnimationTag(MotionModel motion1, MotionModel motion2) {
    List<String> animationTags = new ArrayList<>();
    String duration = String.valueOf(motion2.getT() - motion1.getT() + 1); // offset...
    // x attribute
    animationTags.add(getStartTag(motion1.getShapeType().getPositionXAttr(),
        String.format("%d;%d", motion1.getX(), motion2.getX()), duration,
        String.valueOf(motion1.getT())) + getEndTag()
    );
    // y attribute
    animationTags.add(getStartTag(motion1.getShapeType().getPositionYAttr(),
        String.format("%d;%d", motion1.getY(), motion2.getY()), duration,
        String.valueOf(motion1.getT())) + getEndTag()
    );
    // w attribute
    animationTags.add(getStartTag(motion1.getShapeType().getWidthAttr(),
        String.format("%d;%d", motion1.getWidth(), motion2.getWidth()), duration,
        String.valueOf(motion1.getT())) + getEndTag()
    );
    // h attribute
    animationTags.add(getStartTag(motion1.getShapeType().getHeightAttr(),
        String.format("%d;%d", motion1.getHeight(), motion2.getHeight()), duration,
        String.valueOf(motion1.getT())) + getEndTag()
    );

    // fill attribute
    animationTags.add(getStartTag("fill",
        String.format("rgb(%d,%d,%d);rgb(%d,%d,%d)", motion1.getR(), motion1.getG(), motion1.getB(),
            motion2.getR(), motion2.getG(), motion2.getB()),
        duration, String.valueOf(motion1.getT())
    ) + getEndTag());

    StringBuilder sb = new StringBuilder();
    animationTags.forEach(temp -> sb.append(temp + '\n'));
    return sb.toString();
  }

}




