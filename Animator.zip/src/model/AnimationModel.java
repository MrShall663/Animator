package model;

import java.util.HashMap;
import java.util.List;

/**
 * Represents the model for an animation.
 */
public interface AnimationModel {


  HashMap<String, List<TickModel>> animations = null;
  HashMap<String, String> shapes = null;
  List<String> shapeNames = null;
  int currentTick = 0;
  String fileName = null;

  /**
   * Adds a shape and/or its animation to list of animations.
   *
   * @param name  is the name of the shape.
   * @param shape is the type of shape.
   */
  void addShape(String name, ShapeModel shape);

  /**
   * Adds a shape and/or its animation to the list of animations.
   *
   * @param name  is the name of the shape.
   * @param shape is the type of shape.
   * @param tick  is the time when the shape and/pr animation is added.
   */
  void addShape(String name, ShapeModel shape, int tick);

  /**
   * Increases to the current tick.
   *
   * @param times is the amount to increase the current tick.
   */
  void tick(int times);

  /**
   * Gets the current tick.
   *
   * @return the current tick.
   */
  int getCurrentTick();

  /**
   * Gets the previous tick time for a previous animation.
   *
   * @return the previous tick time for a previous animation.
   */
  int getLastTick();

  /**
   * Gets the names of all shapes in the animations.
   *
   * @return the names of all shapes in the animations.
   */
  List<String> getShapeNames();

  /**
   * Gets the type of shape for a certain named shape.
   *
   * @param name is the name of the shape.
   * @return the type of shape for the given name.
   */
  String getTypeOfShape(String name);

  /**
   * Adds an animation to the list of animations.
   *
   * @param name  is the name of the shape.
   * @param shape is the type of shape.
   * @param tick  is the current time of the animation.
   */
  public void addAnimation(String name, ShapeModel shape, int tick);

  /**
   * Gets the list of animations for a given name.
   *
   * @param name is the given name of a shape.
   * @return the animations for the given name shape.
   */
  List<TickModel> getAnimation(String name);

  /**
   * Checks to see whether the named shape has any animations.
   *
   * @param name is the name of the shape.
   * @return whether the shape has an animation.
   */
  boolean hasShape(String name);
}
