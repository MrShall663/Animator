package model;

import java.util.List;

/**
 * This class represents the model for a shape in the animation.
 */
public interface ShapeModel {


  int getRadius();

  void setRadius(int r);


  /**
   * Sets the type of shape i.e rectangle, ellipse etc.
   *
   * @param shape is the type of shape.
   */
  void setShape(String shape);

  /**
   * Gets the type of shape.
   *
   * @return the type of shape.
   */
  String getShape();

  /**
   * Sets the name of a shape.
   *
   * @param name is the name given to the shape.
   */
  void setName(String name);

  /**
   * Gets the name of a shape.
   *
   * @return the name of a shape.
   */
  String getName();

  /**
   * Sets the coordinates of a shape.
   *
   * @param x is the x coordinate of the shapes position.
   * @param y is the y coordinate of the shapes position.
   */
  void setPosition(int x, int y);

  /**
   * Sets the X coordinate of the shapes position.
   *
   * @param x is the x coordinate of the shapes position.
   */
  void setX(int x);

  /**
   * Gets the x coordinate of the shapes position.
   *
   * @return the x coordinate of the shapes position.
   */
  int getX();

  /**
   * Sets the Y coordinate of the shapes position.
   *
   * @param y is the y coordinate of the shapes position.
   */
  void setY(int y);

  /**
   * Gets the y coordinate of the shapes position.
   *
   * @return the y coordinate of the shapes position.
   */
  int getY();

  /**
   * Sets the dimensions of a shape.
   *
   * @param width  is the width of the shape.
   * @param height is the height of the shape.
   */
  void setDimensions(int width, int height);

  /**
   * Sets the width of the shape.
   *
   * @param width is the width of the shape.
   */
  void setWidth(int width);

  /**
   * Gets the width of the shape.
   *
   * @return the width of the shape.
   */
  int getWidth();

  /**
   * Sets the height of the shape.
   *
   * @param height is the height of the shape.
   */
  void setHeight(int height);

  /**
   * Gets the height of the shape.
   *
   * @return the height of the shape.
   */
  int getHeight();

  /**
   * Sets the color of a shape.
   *
   * @param red   is the red component of the shape's color.
   * @param green is the green component of the shape's color.
   * @param blue  is the blue component of the shape's color.
   */
  void setColor(int red, int green, int blue);

  /**
   * Gets the color of a shape.
   *
   * @return the color of the shape.
   */
  ColorModel getColor();

  /**
   * Gets the shapes.
   *
   * @return list of shapes
   */
  List<ShapeModel> getShapes();


  String getStartTag();

  String getEndTag();
}
