package model;

import java.awt.Color;
import java.util.List;
import java.util.ArrayList;


/**
 * Represents the implementation of the methods in the ShapeModel interface.
 */

public class ShapeModelImpl implements ShapeModel {


  private ShapeEnum shapeType;
  private String name;
  private String shape;
  private int x;
  private int y;
  private int r;
  private int width;
  private int height;
  private ColorModel color;
  private List<MotionModel[]> motions;


  /**
   * Represents the implementation of the methods in the ShapeModel interface.
   *
   * @param shapeType is the type of shape.
   * @param name      is the type of shape.
   * @param shape     is the type of shape.
   * @param x         is the type of shape.
   * @param y         is the type of shape.
   * @param width     is the type of shape.
   * @param height    is the type of shape.
   * @param r         is the type of shape.
   * @param g         is the type of shape.
   * @param b         is the type of shape.
   */
  public ShapeModelImpl(ShapeEnum shapeType, String name, String shape, int x, int y, int width,
      int height, int r, int g, int b) {
    this.shapeType = shapeType;
    this.setShape(shape);
    this.setName(name);
    this.r = r;
    this.setPosition(x, y);
    this.setDimensions(width, height);
    this.color = new ColorModel(r, g, b);
  }


  public void setMotions(List<MotionModel[]> motions) {
    this.motions = motions;
  }

  public List<MotionModel[]> getMotions() {
    return motions;
  }

  @Override
  public int getRadius() {
    return this.r;
  }

  @Override
  public void setRadius(int r) {
    this.r = r;

  }

  /**
   * Sets the type of shape i.e rectangle, ellipse etc.
   *
   * @param shape is the type of shape.
   */
  public void setShape(String shape) {
    this.shape = shape;
  }

  /**
   * Gets the type of shape.
   *
   * @return the type of shape.
   */
  public String getShape() {
    return this.shape;
  }

  /**
   * Sets the name of a shape.
   *
   * @param name is the name given to the shape.
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Gets the name of a shape.
   *
   * @return the name of a shape.
   */
  public String getName() {
    return this.name;
  }

  /**
   * Sets the coordinates of a shape.
   *
   * @param x is the x coordinate of the shapes position.
   * @param y is the y coordinate of the shapes position.
   */
  public void setPosition(int x, int y) {
    this.setX(x);
    this.setY(y);
  }

  /**
   * Sets the X coordinate of the shapes position.
   *
   * @param x is the x coordinate of the shapes position.
   */
  public void setX(int x) {
    this.x = x;
  }

  /**
   * Gets the x coordinate of the shapes position.
   *
   * @return the x coordinate of the shapes position.
   */
  public int getX() {
    return this.x;
  }

  /**
   * Sets the Y coordinate of the shapes position.
   *
   * @param y is the y coordinate of the shapes position.
   */
  public void setY(int y) {
    this.y = y;
  }

  /**
   * Gets the y coordinate of the shapes position.
   *
   * @return the y coordinate of the shapes position.
   */
  public int getY() {
    return this.y;
  }


  /**
   * Sets the dimensions of a shape.
   *
   * @param width  is the width of the shape.
   * @param height is the height of the shape.
   */
  public void setDimensions(int width, int height) throws IllegalArgumentException {
    this.setWidth(width);
    this.setHeight(height);
  }

  /**
   * Sets the width of the shape.
   *
   * @param width is the width of the shape.
   */
  public void setWidth(int width) throws IllegalArgumentException {
    if (width < 0) {
      throw new IllegalArgumentException("Width must be at least 0.");
    }
    this.width = width;
  }

  /**
   * Gets the width of the shape.
   *
   * @return the width of the shape.
   */
  public int getWidth() {
    return this.width;
  }

  /**
   * Sets the height of the shape.
   *
   * @param height is the height of the shape.
   */
  public void setHeight(int height) throws IllegalArgumentException {
    if (height < 0) {
      throw new IllegalArgumentException("Height must be at least 0.");
    }
    this.height = height;
  }

  /**
   * Gets the height of the shape.
   *
   * @return the height of the shape.
   */
  public int getHeight() {
    return this.height;
  }

  /**
   * Sets the color of a shape.
   *
   * @param red   is the red component of the shape's color.
   * @param green is the green component of the shape's color.
   * @param blue  is the blue component of the shape's color.
   */
  public void setColor(int red, int green, int blue) throws IllegalArgumentException {
    if (red < 0 || red > 255 || green < 0 || green > 255 || blue < 0 || blue > 255) {
      throw new IllegalArgumentException("Invalid color. Must be between 0 and 255.");
    }
    this.color = new ColorModel(red, green, blue);
  }

  @Override
  public String toString() {

    return String.format("%s %s %s\n", "shape", name, shape);

  }

  /**
   * Gets the color of a shape.
   *
   * @return the color of the shape.
   */
  public ColorModel getColor() {
    return this.color;
  }

  public Color getSwingColor() {
    return new Color(this.color.getR(), this.color.getG(), this.color.getB());
  }


  public ShapeEnum getShapeType() {
    return shapeType;
  }

  public void setShapeType(ShapeEnum shapeType) {
    this.shapeType = shapeType;
  }

  public List<ShapeModel> getShapeList() {
    return shapeList;
  }

  public void setShapeList(List<ShapeModel> shapeList) {
    this.shapeList = shapeList;
  }


  private List<ShapeModel> shapeList;

  public void animationModel() {
    this.shapeList = new ArrayList<ShapeModel>();
  }

  public List<ShapeModel> getShapes() {
    return shapeList;
  }

  @Override
  public String getStartTag() {
    return null;
  }

  @Override
  public String getEndTag() {
    return null;
  }

  /**
   * setMotionValuesForPositionAndDimesions.
   */
  public void setMotionValuesForPositionAndDimesions(List<MotionModel[]> motionModelsP) {
    this.setX(motionModelsP.get(0)[0].getX());
    this.setY(motionModelsP.get(0)[0].getY());
    this.setWidth(motionModelsP.get(0)[0].getWidth());
    this.setHeight(motionModelsP.get(0)[0].getHeight());
  }

}
