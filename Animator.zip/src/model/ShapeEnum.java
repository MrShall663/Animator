package model;

/**
 * Represent all the shapes in the animation.
 */
public enum ShapeEnum {
  RECTANGLE("R"),
  ELLIPSE("E"),
  CIRCLE("C"),
  CANVAS("CA"),
  MOTION("M"),
  NONE("-");


  private String shapeAbbr;

  ShapeEnum(String shapeAbbr) {
    this.shapeAbbr = shapeAbbr;
  }


  public String getShapeAbbr() {
    return shapeAbbr;
  }

  /**
   * getStartTag.
   *
   * @return getEndTag the view
   */
  public String getStartTag() {
    switch (shapeAbbr.toUpperCase()) {
      case "R":
        return "<rect>";
      case "E":
        return "<ellipse>";
      case "C":
        return "<circle>";
      case "CA":
        return "<svg>";
      case "M":
        return "<animate ";
      default:
        return null;

    }
  }

  /**
   * getPositionXAttr.
   *
   * @return getEndTag the view
   */
  public String getWidthAttr() {
    switch (shapeAbbr.toUpperCase()) {
      case "CA":
      case "R":
        return "width";
      case "E":
        return "rx";
      case "C":
        return "r";
      default:
        throw new RuntimeException("Could not find the width attribute for this unknown shape... ");
    }
  }

  /**
   * getPositionXAttr.
   *
   * @return getEndTag the view
   */
  public String getHeightAttr() {
    switch (shapeAbbr.toUpperCase()) {
      case "CA":
      case "R":
        return "height";
      case "E":
        return "ry";
      case "C":
        return "r";
      default:
        throw new RuntimeException(
            "Could not find the height attribute for this unknown shape... ");
    }
  }

  /**
   * getPositionXAttr.
   *
   * @return getEndTag the view
   */
  public String getPositionYAttr() {
    switch (shapeAbbr.toUpperCase()) {
      case "CA":
      case "R":
        return "y";
      case "C":
      case "E":
        return "cy";
      default:
        throw new RuntimeException("Could not find the y  attribute for this unknown shape... ");
    }
  }

  /**
   * getPositionXAttr.
   *
   * @return getEndTag the view
   */
  public String getPositionXAttr() {
    switch (shapeAbbr.toUpperCase()) {
      case "CA":
      case "R":
        return "x";
      case "C":
      case "E":
        return "cx";
      default:
        throw new RuntimeException("Could not find the x  attribute for this unknown shape... ");
    }
  }

  /**
   * getEndTag.
   *
   * @return getEndTag the view
   */
  public String getEndTag() {
    switch (shapeAbbr.toUpperCase()) {
      case "R":
        return "</rect>";
      case "E":
        return "</ellipse>";
      case "C":
        return "</circle>";
      case "CA":
        return "</svg>";
      case "M":
        return " />";
      default:
        return null;

    }
  }

}

