package model;

/**
 * Represents the implementation of the TickModel interface.
 */
public class TickModelImpl implements TickModel {

  private final int tick;
  private final ShapeModel shape;

  /**
   * Represents the implementation of the TickModel interface.
   *
   * @param shape is the type of shape.
   * @param tick  is the type of shape.
   */
  public TickModelImpl(int tick, ShapeModel shape) {
    if (tick < 0 || shape == null) {
      throw new IllegalArgumentException("Tick must be at least 0, and there must be a shape.");
    }
    this.shape = shape;
    this.tick = tick;
  }

  /**
   * Gets the current tick of the animation.
   *
   * @return the current tick of the animation.
   */
  public int getTick() {
    return this.tick;
  }

  /**
   * Gets the current shape in the animation.
   *
   * @return the current shape in the animation.
   */
  public ShapeModel getShape() {
    return this.shape;
  }

  /**
   * Puts the animation in string format.
   *
   * @return what happens in the animation in string format.
   */
  public String toString() {
    return "Shape "
        + shape.getName() + " "
        + shape.getShape() + "\n"
        + "motion "
        + shape.getName() + " "
        + getTick() + " "
        + shape.getX() + " "
        + shape.getY() + " "
        + shape.getWidth() + " "
        + shape.getHeight() + " "
        + shape.getColor().getR() + " "
        + shape.getColor().getG() + " "
        + shape.getColor().getB() + " ";
  }
}
