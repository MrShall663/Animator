package model;

import java.util.List;

/**
 * This class is the representation of a canvas that has shape animations.
 */
public class CanvasModel {

  private List<ShapeModelImpl> shapeModel;
  private int width;
  private int height;
  private int x;
  private String name;
  private int y;
  private ShapeEnum shapeType;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public int getHeight() {
    return height;
  }

  public void setHeight(int height) {
    this.height = height;
  }

  public int getX() {
    return x;
  }

  public void setX(int x) {
    this.x = x;
  }

  public int getY() {
    return y;
  }

  public void setY(int y) {
    this.y = y;
  }

  public int getWidth() {
    return width;
  }


  public void setWidth(int width) {
    this.width = width;
  }

  public List<ShapeModelImpl> getShapeModel() {
    return shapeModel;
  }

  public void setShapeModel(List<ShapeModelImpl> shapeModel) {
    this.shapeModel = shapeModel;
  }

  public ShapeEnum getShapeType() {
    return shapeType;
  }

  public void setShapeType(ShapeEnum shapeType) {
    this.shapeType = shapeType;
  }

  public String getStartTag() {
    return String
        .format("<svg viewBox=\"%d %d %d %d\" xmlns=\"http://www.w3.org/2000/svg\" >", x, y, width,
            height);
  }

  public String getEndTag() {
    return getShapeType().getEndTag();
  }


  @Override
  public String toString() {
    return String.format("%s %d %d %d %d\n", name, x, y, width, height);
  }
}
